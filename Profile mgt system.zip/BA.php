<html>
    <head>
    <script>
        
            alert("your Business account is successfully created")
        
    </script>
    </head>
</html>