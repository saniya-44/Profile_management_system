<?php
if(isset($_POST['signup']))
{
  $uname=$_POST['u1'];
  $mob=$_POST['m1'];
  $uemail=$_POST['e1'];
  $upass=$_POST['p1'];
  $accounttype=$_POST['ac1'];
  $id=$_POST['id1'];
  $host='localhost';
  $user='root';
  $pass='';
  $dbname='databse';

  $conn=mysqli_connect($host,$user,$pass,$dbname);
  $sql="INSERT INTO login(uname,mob,uemail,upass,accounttype,id) values('$uname','$mob','$uemail','$upass','$accounttype','$id')";
  $query_run=mysqli_query($conn,$sql);
  if($query_run)
  {
    if(isset($_POST['ac1']))
    {
      $value=$_POST['ac1'];
      echo "$value";
      if(($value!="Business Account")&&($value!="Institiution Account"))
      {
        header("Location:student2.php");
      }
      else if(($value!="Personal Account")&&($value!="Institiution Account"))
      {
        header("Location:business.php");
      }
      else{
        header("Location:institiution.php");
      }
    }
  }
  else{
    header("Location:cpp.php");
  }
}
?>
