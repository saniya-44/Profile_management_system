<html>
    <head>
    <script>
        
            alert("your Business account is unsuccessfully created")
        
    </script>
    </head>
</html>