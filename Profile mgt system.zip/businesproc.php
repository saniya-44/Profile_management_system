<?php
if(isset($_POST['press']))
{
  $uname=$_POST['un1'];
  $bname=$_POST['bn1'];
  $bdes=$_POST['bdes1'];
  $badd=$_POST['bad1'];
  $contact=$_POST['con'];
  $uemail=$_POST['ue1'];
  $upass=$_POST['up'];
  $id=$_POST['id2'];
  

  $host='localhost';
  $user='root';
  $pass='';
  $dbname='databse';

  $conn=mysqli_connect($host,$user,$pass,$dbname);
  $sql="INSERT INTO tycoa (uname,bname,bdes,badd,contact,uemail,upass,id) values('$uname','$bname','$bdes','$badd','$contact','$uemail','$upass','$id')";
  $query_run=mysqli_query($conn,$sql);
  if($query_run)
  {
    $query="SELECT * FROM tycoa where uemail='$uemail' and  upass='$upass'";
      if($result=mysqli_query($conn,$query))
      {
        if(mysqli_num_rows($result)>0)
        {
          
          echo "<table border=1 align='center' bordercolor='blue'>";
          echo "<tr>";
          echo "<th>username</th>";
          echo "<th>Business name</th>";
          echo "<th>Business Description</th>";
          echo "<th>Business Address</th>";
          echo "<th>mobile number</th>";
          echo "<th>Email</th>";
          echo "<th>password</th>";
          echo "<th>ID</th>";
          echo "</tr>";
      $query_run=mysqli_query($conn,$query);
      while($row=mysqli_fetch_array($query_run))
      {
        echo "<u><h1 align='center'>Your Business Account is Signup </h1></u>";

        echo "<tr>";
        echo "<td>".$row['uname']."</td>";
        echo "<td>".$row['bname']."</td>";
        echo "<td>".$row['bdes']."</td>";
        echo "<td>".$row['badd']."</td>";
        echo "<td>".$row['contact']."</td>";
        echo "<td>".$row['uemail']."</td>";
        echo "<td>".$row['upass']."</td>";
        echo "<td>".$row['id']."</td>";
        echo "</tr>";
    }
    echo "</table>";
    }
    echo "<p align='center'><a href='sb.php'>logout your Business Account</a></p>";
    echo "<p align='center'><a href='updatebusines.php'>Update your Business Account</a></p>";
  }
    }
  
  else{
    header("Location:BAA.php");
  }

}
?>