<?php
  $uname=$_POST['u1'];
  $mob=$_POST['m1'];
  $uemail=$_POST['e1'];
  $upass=$_POST['p1'];
  $accounttype=$_POST['ac1'];
  $id=$_POST['ids'];
  $host='localhost';
  $user='root';
  $pass='';
  $dbname='databse';

  $conn=mysqli_connect($host,$user,$pass,$dbname);
if(!$conn)
{

    die("connection is failed".mysqli_error());
}
$sql="UPDATE login SET uname='$uname',mob='$mob',uemail='$uemail',upass='$upass',accounttype='$accounttype' WHERE id=$id";
if($conn->query($sql)===TRUE)
{
    echo "<h1 align='center'>your account is updated</h1>";
    }
    else
    {
        echo "<h1 align='center'>your account is not updated</h1>";
  }

?>
