<?php
$uemail=$_POST['em'];
$upass=$_POST['pas'];
$con=new mysqli("localhost","root","","databse");
if(!$con)
{

    die("connection is failed".mysqli_error());
}
$sql="DELETE FROM login WHERE uemail='$uemail' AND upass='$upass'";
$result=mysqli_query($con,$sql);
if(mysqli_affected_rows($con)>0)
{
    echo "<h1 align='center'>Your Logout successfully</h1>";
}
else{
    echo "<h1 align='center'>Your Logout unsuccessfully Please enter Correct Email-ID or Password</h1>";
}
?>
