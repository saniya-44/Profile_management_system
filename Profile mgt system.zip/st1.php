<html>
    <head>
    <script>
        
            alert("your personal account is unsuccessfully created")
        
    </script>
    </head>
</html>