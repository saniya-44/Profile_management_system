<?php
$uemail=$_POST['em'];
$upass=$_POST['pas'];
$con=new mysqli("localhost","root","","databse");
if(!$con)
{

    die("connection is failed".mysqli_error());
}
$uemail="enter email:";
$sql="DELETE FROM login WHERE uemail=$uemail";
$result=mysqli_query($con,$sql);
if(mysqli_affected_rows($con)>0)
{
    echo "Your Sign up successfully";
}
else{
    echo "Your Sign up unsuccessfully";
}
?>