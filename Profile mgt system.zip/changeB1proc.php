<?php
$uemail=$_POST['emi2'];
$upass=$_POST['passw2'];
$con=new mysqli("localhost","root","","databse");
if($con->connect_error){
  die("failed to connect:".$con->conect_error);
}
$query="SELECT * FROM tycoa where uemail='$uemail'";
      if($result=mysqli_query($con,$query))
      {
        if(mysqli_num_rows($result)>0)
        {
  $sql="UPDATE tycoa SET upass='$upass' WHERE uemail='$uemail'";
  if($con->query($sql)===TRUE)
  {
     echo "<h1 align='center'>your password is successfully change</h1>";
     echo "<h3 align='center'>your new password is <u>$upass</u></h3>";
  }
  else{
    echo "<h1 align='center'>your password is not change</h1>";
  }
}
else{
     echo "<h1 align='center'>your password is not change</h1>";
}
      }

?>