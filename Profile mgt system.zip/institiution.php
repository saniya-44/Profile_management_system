<?php
if(isset($_POST['click']))
{
  $un=$_POST['in1'];
  $uemail=$_POST['in2'];
  $upass=$_POST['in3'];
  $mon=$_POST['in4'];
  $intn=$_POST['in5'];
  $intc=$_POST['in6'];
  $intl=$_POST['in7'];
  $gopr=$_POST['in8'];
  $intad=$_POST['in9'];
  $intst=$_POST['in10'];
  $intd=$_POST['in11'];
  $intp=$_POST['in12'];
  $id=$_POST['id7'];

  $host='localhost';
  $user='root';
  $pass='';
  $dbname='databse';

  $conn=mysqli_connect($host,$user,$pass,$dbname);
  $sql="INSERT INTO tycoa2(un,uemail,upass,mon,intn,intc,intl,gopr,intad,intst,intd,intp,id) values('$un','$uemail','$upass','$mon','$intn','$intc','$intl','$gopr','$intad','$intst','$intd','$intp','$id')";
  $query_run=mysqli_query($conn,$sql);
  if($query_run)
  {
    header("Location:iaa.php");
  }
  else{
    header("Location:iaa1.php");
  }
}
?>

<html>
<head>
    <Title>Login Form </Title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<style>
    * {
        Margin: 0;
        Padding: 0;
        Box-Sizing: Border-Box;
        Font-Family: "Poppins", Sans-Serif;
      }
      Body {
      background-color:dodgerblue; 
      }
      label{
        width: 200px;
        display:inline-block;
      }
      .Login-Page {
        Height: 100vh;
        Width: 100%;
        Align-Items: Center;
        Display: Flex;
        Justify-Content: Center;
      }
      
      .Form {
        Position: Relative;
        Filter: Drop-Shadow(0 0 2px white);
        Border-Radius: 5px;
        Width: 800px;
        Height: 1200px;
        Background-Color: white;
        Padding: 40px;
      }
      
      .Form Img {
        Position: Absolute;
        Height: 20px;
        Top: 230px;
        Right: 60px;
        Cursor: Pointer;
      }
      
      .Form Input {
        Outline: 0;
        Background: #F2f2f2;
        Border-Radius: 4px;
        Width: 100%;
        Border: 0;
        Margin: 1px 0;
        Padding: 15px;
        Font-Size: 14px;
      }
      
      .Form Input:focus {
        Box-Shadow: 0 0 5px 0 Rgba(106, 98, 210);
      }
      
      Span {
        Color: Red;
        Margin: 10px 0;
        Font-Size: 14px;
      }
      
      .Form Button {
        Outline: 0;
        Background: dodgerblue;
        Width: 100%;
        Border: 0;
        Margin-Top: 10px;
        Border-Radius: 3px;
        Padding: 15px;
        Color: #Ffffff;
        Font-Size: 15px;
        -Webkit-Transition: All 0.3 Ease;
        Transition: All 0.4s Ease-In-Out;
        Cursor: Pointer;
      }
      
      .Form Button:hover,
      .Form Button:active,
      .Form Button:focus {
        Background: Black;
        Color: #Fff;
      }
      
      .Message {
        Margin: 15px 0;
        Text-Align: Center;
      }
      .Form .Message A {
        Font-Size: 14px;
        Color: #6a62d2;
        Text-Decoration: None;
     }
     .radio {
      font-size: 20px;
      font-weight: 100;
      display: inline-block;
      text-transform: capitalize;
      vertical-align: middle;
      color: black;
      position: relative;
      padding-left: 50px;
  }
  label{
    position: relative;
    color: black;
    border: 2px solid black;
    border-radius: 5px;
    
  }
  .radio + .radio{
    margin-left: 20px;
  }
  .radio input[type="radio"]{
    display: none;
  }
  .radio span{
    height: 20px;
    width: 20px;
    border: 3px solid black;
    border-radius: 50%;
    position: absolute;
    right: 150;
    top: -10px;
  }
  .radio span:after{
    content: " ";
    height: 20px;
    width: 20px;
    background:black ;
    display: block;
    position: absolute;
    left: 50%;
    top:50%;
    transform: translate(-50%,-50%) scale(0);
    border-radius: 50%;
    transition: 300ms ease-in-out 0s;
   }
  .radio input[type="radio"]:checked + span:after{
    transform: translate(-50%,-50%) scale(1);
  }
  * {box-sizing: border-box;}

.container_input {
  display: flex;
  width: 100%;
  margin-bottom: 15px;
}

.icon {
  padding: 10px;
  background: dodgerblue;
  color: white;
  min-width: 50px;
  text-align: center;
}

.input-field {
  width: 100%;
  padding: 10px;
  outline: none;
}
.eye{

margin-left: -19px;
margin-top: 14px;

color: black;
}
    </style>  
<body>
    
    <Div Class="login-Page">
        <Div Class="form">
            <Form action="institiuproc.php" method="POST" Class="Login-Form "  Target="_blank">
                <u><H2 align="center">Create YOUR INSTITUTION Account</H2></u><br>

                <div class="container_input">
            <i class="fa fa-user icon"></i>
                <Input Type="Text" Required Placeholder="Enter your name" name="in1" pattern="[A-Za-z].{5,}" Id="iname" required ></div>
                <div class="container_input">
            <i class="fa fa-envelope icon"></i>
                <Input Type="Text" Required Placeholder="Email ID" name="in2" pattern="(~!@#$%^&*()_+|<>?,./:;][}=\-) [A-Za-z].{10,}" Id="iemail" required ></div>
                <div class="container_input">
            <i class="fa fa-key icon"></i>
                <Input Type="password" Required Placeholder="password" name="in3" pattern="[0-9].{10,}" Id="tp" required >
                <i class="fa fa-eye eye" id="togglePassword" ></i> </div>
                <div class="container_input">
            <i class="fa fa-phone icon"></i>
                <Input Type="Text" Required Placeholder="Mobile number" name="in4" pattern="[0-9].{10,}" Id="imob" required ></div>
                <div class="container_input">
            <i class="fa fa-institution icon"></i>
                <Input Type="Text" Required Placeholder="Institution name" name="in5" pattern="[A-Za-z].{5,}" Id="inst" required ></div>
                <div class="container_input">
            <i class="fa fa-institution  icon"></i>
                <Input Type="Text" Required Placeholder="Institution code"  name="in6" Id="code" pattern="[0-9].{3,}" required></div>
               
                <label class="label"> <b>your institiution Logo: </b> <div class="container_input">
            <i class="fa fa-cloud-upload  icon"></i><Input Type="file" Required Placeholder="Institution logo" name="in7" Id="logo" required></div></label><br><br>
<b>your institiution is Government or Private: </b><br><br>
                  <label class="radio">
                  <Input Type="radio"   name="in8" value="Government" required> Government<span></span></label>
                      <label class="radio">                        
                        <Input Type="radio"  name="in8" value="private" required> private<span></span></label>
                          <br>
<br>
                  
<div class="container_input">
            <i class="fa fa-address-card icon"></i>
                         <input type="textarea"  Required Placeholder="institution Address" name="in9" pattern="[A-Za-z].{5,}" id="ia" required></div>
                                           
<div class="container_input">
            <i class="fa fa-graduation-cap icon"></i>
                         <input type="text"  Required Placeholder="Main staff name" name="in10"  pattern="[A-Za-z].{10,}" id="msn" required></div><br>
                         <div class="container_input">
            <i class="fa fa-users icon"></i>
                         <input type="text" name="in11" Required Placeholder="designation(chairman,founder,freasures,supervisor)" pattern="[A-Za-z].{10,}" id="de" required></div>
                         
                         <label class="label"> <b>your institiution photo: </b><div class="container_input">
            <i class="fa fa-cloud-upload  icon"></i><input type="file" name="in12" ></div></label><br><br>
                         <div class="container_input">
            <i class="fa fa-id-card-o icon"></i>
                         <Input Type="text" Required Placeholder="Your ID" name="id7" pattern="[0-9].{1,}" Id="id" required=""></div>
                          <script>
                            function back()
                            {
                                window.open("cpp.php");
                            }
                            const togglePassword=document.querySelector("#togglePassword");
                    const password=document.querySelector("#tp");
                    togglePassword.addEventListener("click",function(e){
                      const type=password.getAttribute("type")==="password" ? "text" : "password";
                      password.setAttribute('type',type);
                      this.classList.toggle("fa-eye-slash");
                    });
             
                          </script>
                <Button Type="Submit" name="click" onclick="institute()">Signup</Button>
                <Button type="button" onclick="back()">Back</Button>
              
            </Form>
        </Div>
    </Div>
    <Script Src="Indexes.Js"></Script>
    
</Body>

</Html>
