<html>
    <head>
    <script>
        
            alert("Your Institiution Account login is successfull")
        
    </script>
    </head>
</html>