<?php
$uemail=$_POST['em1'];
$upass=$_POST['pas1'];
$con=new mysqli("localhost","root","","databse");
if(!$con)
{

    die("connection is failed".mysqli_error());
}
$upass=$upass;
$sql="DELETE FROM tycoa1 WHERE upass=$upass";
$result=mysqli_query($con,$sql);
if(mysqli_affected_rows($con)>0)
{
    echo "<h1 align='center'>Your Personal Account Signup successfully</h1>";
}
else{
    echo "<h1 align='center'>Your Personal Account Signup  unsuccessfully</h1>";
}
?>
