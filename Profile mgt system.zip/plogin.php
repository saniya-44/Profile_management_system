
<html>
<head>
   
    <Title>Login Form </Title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<style>
    * {
        Margin: 0;
        Padding: 0;
        Box-Sizing: Border-Box;
        Font-Family: "Poppins", Sans-Serif;
      }
      Body {
      background-color:dodgerblue; 
      }
      label{
        width: 200px;
        display:inline-block;
      }
      .Login-Page {
        Height: 100vh;
        Width: 100%;
        Align-Items: Center;
        Display: Flex;
        Justify-Content: Center;
      }
      
      .Form {
        Position: Relative;
        Filter: Drop-Shadow(0 0 2px white);
        Border-Radius: 5px;
        Width: 500px;
        Height: 400px;
        Background-Color: white;
        Padding: 40px;
      }
      
      .Form Img {
        Position: Absolute;
        Height: 20px;
        Top: 230px;
        Right: 60px;
        Cursor: Pointer;
      }
      
      .Form Input {
        Outline: 0;
        Background: #F2f2f2;
        Border-Radius: 4px;
        Width: 100%;
        Border: 0;
        Margin: 1px 0;
        Padding: 15px;
        Font-Size: 14px;
      }
      
      .Form Input:focus {
        Box-Shadow: 0 0 5px 0 Rgba(106, 98, 210);
      }
      
      Span {
        Color: Red;
        Margin: 10px 0;
        Font-Size: 14px;
      }
      
      .Form Button {
        Outline: 0;
        Background: dodgerblue;
        Width: 100%;
        Border: 0;
        Margin-Top: 10px;
        Border-Radius: 3px;
        Padding: 15px;
        Color: #Ffffff;
        Font-Size: 15px;
        -Webkit-Transition: All 0.3 Ease;
        Transition: All 0.4s Ease-In-Out;
        Cursor: Pointer;
      }
      
      .Form Button:hover,
      .Form Button:active,
      .Form Button:focus {
        Background: Black;
        Color: #Fff;
      }
      
      .Message {
        Margin: 15px 0;
        Text-Align: Center;
      }
      .Form .Message A {
        Font-Size: 14px;
        Color: #6a62d2;
        Text-Decoration: None;
      }
      * {box-sizing: border-box;}

.container_input {
  display: flex;
  width: 100%;
  margin-bottom: 15px;
}

.icon {
  padding: 10px;
  background: dodgerblue;
  color: white;
  min-width: 50px;
  text-align: center;
}

.input-field {
  width: 100%;
  padding: 10px;
  outline: none;
}
.eye{

margin-left: -19px;
margin-top: 14px;

color: black;
}
    </style>  
<body>
    
    <Div Class="login-Page">
        <Div Class="form">
            <Form Class="Login-Form " action="process1.php" method="POST" Target="_blank">
                <u><H2 align="center">Login Personal Account</H2></u><br>
                <div class="container_input">
            <i class="fa fa-user icon"></i>
                <Input class="input_field" Type="text"  name="emi1" Required Placeholder="Email address" pattern="(~!@#$%^&*()_+|<>?,./:;][}=\-) [A-Za-z].{10,}" Id="em" required=""></div>
                <div class="container_input">
            <i class="fa fa-key icon"></i>
                <Input class="input_field" Type="password"  name="passw1" Required Placeholder="password" pattern="[0-9].{6,}" Id="tp" required>
                <i class="fa fa-eye eye" id="togglePassword" ></i>  </div>
                
                    
                    <script>
          
              function hello()
              {
                window.open("login.php");
              }
              const togglePassword=document.querySelector("#togglePassword");
                    const password=document.querySelector("#tp");
                    togglePassword.addEventListener("click",function(e){
                      const type=password.getAttribute("type")==="password" ? "text" : "password";
                      password.setAttribute('type',type);
                      this.classList.toggle("fa-eye-slash");
                    });
                            
</script>
<Button Type="Submit"  name="plogin" >Login</Button>
<Button Type="Submit" onclick="hello()">Back</Button>

<P Class="Message"><A Href="changeP1.php">Change Your Password?</A></P>
            </Form>
        </Div>
    </Div>
    <Script Src="Indexes.Js"></Script>
    
</Body>

</Html>


    