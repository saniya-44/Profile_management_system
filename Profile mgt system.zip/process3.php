<?php
$uemail=$_POST['emai1'];
$upass=$_POST['passwo1'];
$con=new mysqli("localhost","root","","databse");
if($con->connect_error){
  die("failed to connect:".$con->conect_error);
}
else{
  $stmt=$con->prepare("select *from tycoa2 where uemail=?");
  $stmt->bind_param("s",$uemail);
  $stmt->execute();
  $stmt_result=$stmt->get_result();
  if($stmt_result->num_rows>0){
    $data=$stmt_result->fetch_assoc();
    if($data['upass']==$upass){
      $query="SELECT * FROM tycoa2 where uemail='$uemail' and  upass='$upass'";
      if($result=mysqli_query($con,$query))
      {
        if(mysqli_num_rows($result)>0)
        {
          
          echo "<table border=1 align='center' bordercolor='blue'>";
          echo "<tr>";
          echo "<th>username</th>";
          echo "<th>Email</th>";
          echo "<th>password</th>";
          echo "<th>Mobile Number</th>";
          echo "<th>Institiution Name</th>";
          echo "<th>Institiution Code</th>";
          echo "<th>Institiution Logo</th>";
          echo "<th>Institiution Government/Private</th>";
          echo "<th>Institiution address</th>";
          echo "<th>Institiution Staff name</th>";
          echo "<th>Institiution Designation</th>";
          echo "<th>Institiution Photo</th>";
          echo "<th>ID</th>";
          echo "</tr>";
      $query_run=mysqli_query($con,$query);
      while($row=mysqli_fetch_array($query_run))
      {
        echo "<u><h1 align='center'>welcome ".$row['un']."</h1></u>";

        echo "<tr>";
        echo "<td>".$row['un']."</td>";
        echo "<td>".$row['uemail']."</td>";
        echo "<td>".$row['upass']."</td>";
        echo "<td>".$row['mon']."</td>";
        echo "<td>".$row['intn']."</td>";
        echo "<td>".$row['intc']."</td>";
        echo "<td>".$row['intl']."</td>";
        echo "<td>".$row['gopr']."</td>";
        echo "<td>".$row['intad']."</td>";
        echo "<td>".$row['intst']."</td>";
        echo "<td>".$row['intd']."</td>";
        echo "<td>".$row['intp']."</td>";
        echo "<td>".$row['id']."</td>";
        echo "</tr>";
    }
    echo "</table>";
    }
    echo "<p align='center'><a href='si.php'>logout your Institiution Account</a></p>";
    echo "<p align='center'><a href='updateinst.php'>Update your Institiution Account</a></p>";
    echo "<p align='center'><a href='#'><select id='theme-selector' onchange='color()'>
    <option value='1'>Select Theme</option>
    <option value='lightblue'>Light Blue</option>
    <option value='blue'>Blue</option>
    <option value='lightgreen'>Light Green</option>
    <option value='green'>Green</option>
    <option value='lightgray'>Light Gray</option>
    <option value='gray'>Gray</option>
    <option value='lightyellow'>Light Yellow</option>
    <option value='yellow'>Yellow</option>
    <option value='lightpink'>Light Pink</option>
    <option value='pink'>Pink</option>
    <option value='red'>Red</option>
    <option value='orange'>Orange</option>
    <option value='brown'>Brown</option>
  </select></a></p>";
  
  echo "<script>";
  echo "function color(){
    var x=document.getElementById('theme-selector').value;
    document.body.style.backgroundColor=x;
}";
echo "</script>";
  }
    }
    else{
      header("Location:ilogin2.php");
    }
  }
  else{
    header("Location:ilogin2.php");
  }
}
?>