<?php
if(isset($_POST['next']))
{
  $nm=$_POST['un1'];
  $age=$_POST['age'];
  $bdy=$_POST['bdy'];
  $abself=$_POST['ays'];
  $ca=$_POST['ca1'];
  $con1=$_POST['cn1'];
  $uemail=$_POST['emil'];
  $upass=$_POST['pass'];
  $id=$_POST['id6'];
  

  $host='localhost';
  $user='root';
  $pass='';
  $dbname='databse';

  $conn=mysqli_connect($host,$user,$pass,$dbname);
  $sql="INSERT INTO tycoa1(nm,age,bdy,abself,ca,con1,uemail,upass,id) values('$nm','$age','$bdy','$abself','$ca','$con1','$uemail','$upass','$id')";
  $query_run=mysqli_query($conn,$sql);
  if($query_run)
  {
    header("Location:st.php");
  }
  else{
    header("Location:st1.php");
  }
}
?>


<html>
<head>
   
    <Title>Login Form </Title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<style>
    * {
        Margin: 0;
        Padding: 0;
        Box-Sizing: Border-Box;
        Font-Family: "Poppins", Sans-Serif;
      }
      body {
        background-color:dodgerblue; 
    
      }
      label{
        width: 200px;
        display:inline-block;
      }
      .Login-Page {
        Height: 100vh;
        Width: 100%;
        Align-Items: Center;
        Display: Flex;
        Justify-Content: Center;
      }
      
      .Form {
        Position: Relative;
        Filter: Drop-Shadow(0 0 2px white);
        Border-Radius: 5px;
        Width: 700px;
        Height: 820px;
        Background-Color: white;
        Padding: 40px;
      }
      
      .Form Img {
        Position: Absolute;
        Height: 20px;
        Top: 230px;
        Right: 60px;
        Cursor: Pointer;
      }
      
      .Form Input {
        Outline: 0;
        Background: #F2f2f2;
        Border-Radius: 4px;
        Width: 100%;
        Border: 0;
        Margin: 1px 0;
        Padding: 15px;
        Font-Size: 14px;
      }
      
      .Form Input:focus {
        Box-Shadow: 0 0 5px 0 Rgba(106, 98, 210);
      }
      
      Span {
        Color: Red;
        Margin: 10px 0;
        Font-Size: 14px;
      }
      
      .Form Button {
        Outline: 0;
        Background: dodgerblue;
        Width: 100%;
        Border: 0;
        Margin-Top: 10px;
        Border-Radius: 3px;
        Padding: 15px;
        Color: #Ffffff;
        Font-Size: 15px;
        -Webkit-Transition: All 0.3 Ease;
        Transition: All 0.4s Ease-In-Out;
        Cursor: Pointer;
      }
      
      .Form Button:hover,
      .Form Button:active,
      .Form Button:focus {
        Background: Black;
        Color: #Fff;
      }
      
      .Message {
        Margin: 15px 0;
        Text-Align: Center;
      }
      .Form .Message A {
        Font-Size: 14px;
        Color: #6a62d2;
        Text-Decoration: None;
      }
      * {box-sizing: border-box;}

.container_input {
  display: flex;
  width: 100%;
  margin-bottom: 15px;
}

.icon {
  padding: 10px;
  background: dodgerblue;
  color: white;
  min-width: 50px;
  text-align: center;
}

.input-field {
  width: 100%;
  padding: 10px;
  outline: none;
}
.eye{
margin-left: -19px;
margin-top: 14px;
color: black;
}
    </style>  
<body>
    
    <Div Class="login-Page">
        <Div Class="form">
            <Form Class="Login-Form " action="studentproc.php" method="POST" Target="_blank">
              <u><H2 align="center">Personal Account</H2></u><br>
              <div class="container_input">
            <i class="fa fa-user icon"></i>
                <input type="text" name="un1"  placeholder=" Your Name" pattern="[A-Za-z].{10,}" required></div>
                <div class="container_input">
            <i class="fa fa-child icon"></i>
<input type="text"  name="age" placeholder="Enter age" pattern="(~!@#$%^&*()_+|<>?,./:;][}=\-) [A-Za-z].{10,}" required></div>
<div class="container_input">
            <i class="fa fa-birthday-cake icon"></i>
<input type="text"  name="bdy" placeholder="date of birth-dd/mm/yyyy" pattern="(~!@#$%^&*()_+|<>?,./:;][}=\-) [0-9].{10,}" required></div>
<div class="container_input">
            <i class="fa fa-id-card icon"></i>
<input type="textarea"  name="ays" placeholder="About yourself" pattern="(~!@#$%^&*()_+|<>?,./:;][}=\-) [A-Za-z].{10,}" required></div>
<div class="container_input">
            <i class="fa fa-address-card icon"></i>
<input type="textarea"  name="ca1" placeholder="Current Addres" pattern="(.,/\)[A-Za-z].{10,}" required></div>
<div class="container_input">
            <i class="fa fa-phone icon"></i>
<input type="Number"   name="cn1" placeholder="contact number" pattern="[0-9].{10,}" required></div>
<div class="container_input">
            <i class="fa fa-envelope icon"></i>
<input type="email"  name="emil" placeholder="Email address"  pattern="(~!@#$%^&*()_+|<>?,./:;][}=\-) [A-Za-z].{10,}" required></div>
<div class="container_input">
            <i class="fa fa-key icon"></i>
<Input Type="password" name="pass" Required Placeholder="password" id="tp" pattern="(~!@#$%^&*()_+|<>?,./:;][}=\-) [A-Za-z].{10,}"required> 
<i class="fa fa-eye eye" id="togglePassword" ></i> </div>
<div class="container_input">
            <i class="fa fa-id-card-o icon"></i>
<Input Type="text" Required Placeholder="Your ID" name="id6" pattern="[0-9].{1,}"  required=""></div>
<script>
                            function back()
                            {
                                window.open("cpp.php");
                            }
                            const togglePassword=document.querySelector("#togglePassword");
                    const password=document.querySelector("#tp");
                    togglePassword.addEventListener("click",function(e){
                      const type=password.getAttribute("type")==="password" ? "text" : "password";
                      password.setAttribute('type',type);
                      this.classList.toggle("fa-eye-slash");
                    });
                            </script>
                <Button Type="Submit" name="next" >Signup</Button>
                <Button type="button" onclick="back()">Back</Button>
                
            </Form>
        </Div>
    </Div>
    <Script Src="Indexes.Js"></Script>
    
</Body>

</Html>



