<html>
    <head>
    <script>
        
            alert("your Account is Logout")
        
    </script>

</head>
</html>