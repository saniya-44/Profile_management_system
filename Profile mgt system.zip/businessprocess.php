<?php
  $uname=$_POST['un1'];
  $bname=$_POST['bn1'];
  $bdes=$_POST['bdes1'];
  $badd=$_POST['bad1'];
  $contact=$_POST['con'];
  $uemail=$_POST['ue1'];
  $upass=$_POST['up'];
  $id=$_POST['id3'];

  $host='localhost';
  $user='root';
  $pass='';
  $dbname='databse';

  $conn=mysqli_connect($host,$user,$pass,$dbname);
  if(!$conn)
  {
  
      die("connection is failed".mysqli_error());
  }
  $sql="UPDATE tycoa SET uname='$uname',bname='$bname',bdes='$bdes',badd='$badd',contact='$contact',uemail='$uemail',upass='$upass',id='$id' WHERE id=$id";
  if($conn->query($sql)===TRUE)
  {
      echo "<h1 align='center'>your Business account is updated</h1>";
      }
      else
      {
          echo "<h1 align='center'>your Business account is not updated</h1>";
    }
  
  ?>