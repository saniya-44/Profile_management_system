<?php
  $nm=$_POST['un1'];
  $age=$_POST['age'];
  $bdy=$_POST['bdy'];
  $abself=$_POST['ays'];
  $ca=$_POST['ca1'];
  $con1=$_POST['cn1'];
  $uemail=$_POST['emil'];
  $upass=$_POST['pass'];
  $id=$_POST['id10'];
  
  $host='localhost';
  $user='root';
  $pass='';
  $dbname='databse';

  $conn=mysqli_connect($host,$user,$pass,$dbname);
  $sql="UPDATE tycoa1 SET nm='$nm',age='$age',bdy='$bdy',abself='$abself',ca='$ca',con1='$con1',uemail='$uemail',upass='$upass',id='$id' WHERE id=$id";
  if($conn->query($sql)===TRUE)
  {
      echo "<h1 align='center'>your Personal account is updated</h1>";
      }
      else
      {
          echo "<h1 align='center'>your Personal account is not updated</h1>";
    }
  
?>