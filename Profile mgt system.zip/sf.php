<?php
if(isset($_POST['s1']))
{
  $Names=$_POST['n1'];
  $Mobilenumber=$_POST['n2'];
  
  $host='localhost';
  $user='root';
  $pass='';
  $dbname='mydatabse';

  $conn=mysqli_connect($host,$user,$pass,$dbname);
  $sql="INSERT INTO login(Names,Mobilenumber) values('$Names','$Mobilenumber')";
  mysqli_query($conn,$sql);

}
?>
<htmL>
    <head>
        <title>PHP</title>
    </head>
    <body>
    <form action="#" method="POST">
        <input tyep="text" name="n1" required placeholder="enter your name">
        <input tyep="text" name="n2" required placeholder="enter your mobile number">
        <Button type="submit" name="s1">submit</Button>
        </form>
    </form>
    </body>
</htmL>