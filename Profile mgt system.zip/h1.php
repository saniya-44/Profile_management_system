<html>
<head>
<title>PHP</title>
</head>
<body>
<?php
echo "hi";
?>
</body>
</html>