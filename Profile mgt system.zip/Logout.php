<html>
<head>
   
    <Title>Logout Form </Title>
</head>
<body>
 <Div Class="logout-Page">
        <Div Class="form">
		
            <Form Class="Logout-Form "  Target="_blank" action="cpp.html">
                
                <Input Type="text" Required Placeholder="Username" Id="User" required=""><br>
                <Input Type="text" Required Placeholder="Mobile number" Id="mob" required=""><br>
                <Input Type="text" Required Placeholder="Email address" Id="em" required=""><br>
                <Input Type="text" Required Placeholder="password" Id="word" required=""><br>
                <a href="cpp.html">
		        <button>Logout</button></a>
       </Div>
 </Div>
</body>

</html>
                