<?php
if(isset($_POST['next']))
{
  $nm=$_POST['un1'];
  $age=$_POST['age'];
  $bdy=$_POST['bdy'];
  $abself=$_POST['ays'];
  $ca=$_POST['ca1'];
  $con1=$_POST['cn1'];
  $uemail=$_POST['emil'];
  $upass=$_POST['pass'];
  $id=$_POST['id6'];
  

  $host='localhost';
  $user='root';
  $pass='';
  $dbname='databse';

  $conn=mysqli_connect($host,$user,$pass,$dbname);
  $sql="INSERT INTO tycoa1(nm,age,bdy,abself,ca,con1,uemail,upass,id) values('$nm','$age','$bdy','$abself','$ca','$con1','$uemail','$upass','$id')";
  $query_run=mysqli_query($conn,$sql);
  if($query_run)
  {
    $query="SELECT * FROM tycoa1 where uemail='$uemail' and  upass='$upass'";
      if($result=mysqli_query($conn,$query))
      {
        if(mysqli_num_rows($result)>0)
        {
          
          echo "<table border=1 align='center' bordercolor='blue'>";
          echo "<tr>";
          echo "<th>username</th>";
          echo "<th>Age</th>";
          echo "<th>Birth Date</th>";
          echo "<th>About your self</th>";
          echo "<th>Address</th>";
          echo "<th>mobile number</th>";
          echo "<th>Email</th>";
          echo "<th>password</th>";
          echo "<th>ID</th>";
          echo "</tr>";
      $query_run=mysqli_query($conn,$query);
      while($row=mysqli_fetch_array($query_run))
      {
        echo "<u><h1 align='center'>welcome ".$row['nm']."</h1></u>";

        echo "<tr>";
        echo "<td>".$row['nm']."</td>";
        echo "<td>".$row['age']."</td>";
        echo "<td>".$row['bdy']."</td>";
        echo "<td>".$row['abself']."</td>";
        echo "<td>".$row['ca']."</td>";
        echo "<td>".$row['con1']."</td>";
        echo "<td>".$row['uemail']."</td>";
        echo "<td>".$row['upass']."</td>";
        echo "<td>".$row['id']."</td>";
        echo "</tr>";
    }
    echo "</table>";
    }
    echo "<p align='center'><a href='pa.php'>logout your Personal Account</a></p>";
    echo "<p align='center'><a href='updatepersonal.php'>Update your Personal Account</a></p>";
  }
    }
  
  else{
    header("Location:st1.php");
  }
}
?>