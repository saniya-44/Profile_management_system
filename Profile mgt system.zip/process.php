<?php
$uemail=$_POST['email'];
$upass=$_POST['password'];
$con=new mysqli("localhost","root","","databse");
if($con->connect_error){
  die("failed to connect:".$con->conect_error);
}
else{
  $stmt=$con->prepare("select *from login where uemail=?");
  $stmt->bind_param("s",$uemail);
  $stmt->execute();
  $stmt_result=$stmt->get_result();
  if($stmt_result->num_rows>0){
    $data=$stmt_result->fetch_assoc();
    if($data['upass']==$upass){
      $query="SELECT * FROM login where uemail='$uemail' and  upass='$upass'";
      if($result=mysqli_query($con,$query))
      {
        if(mysqli_num_rows($result)>0)
        {
          
          echo "<table border=1 align='center' bordercolor='blue'>";
          echo "<tr>";
          echo "<th>username</th>";
          echo "<th>Mobile Number</th>";
          echo "<th>Email</th>";
          echo "<th>password</th>";
          echo "<th>Acount type</th>";
          echo "<th>ID</th>";
          echo "</tr>";
      $query_run=mysqli_query($con,$query);
      while($row=mysqli_fetch_array($query_run))
      {
        echo "<u><h1 align='center'>welcome ".$row['uname']."</h1></u>";

        echo "<tr>";
        echo "<td>".$row['uname']."</td>";
        echo "<td>".$row['mob']."</td>";
        echo "<td>".$row['uemail']."</td>";
        echo "<td>".$row['upass']."</td>";
        echo "<td>".$row['accounttype']."</td>";
        echo "<td>".$row['id']."</td>";
        echo "</tr>";
    }
    echo "</table>";
    }
    echo "<p align='center'><a href='signup.php'>logout your Account</a></p>";
    echo "<p align='center'><a href='updatecpp.php'>Update your Account</a></p>";
  }
}
    else{
      header("Location:iup.php");
    }
  }
  else{
    header("Location:iup.php");
  }
}
?>