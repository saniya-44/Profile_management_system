<html>
    <head>
    <script>
        
            alert("your Institiution account is successfully created")
        
    </script>
    </head>
</html>