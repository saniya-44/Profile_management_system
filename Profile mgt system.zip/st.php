<html>
    <head>
    <script>
        
            alert("your personal account is successfully created")
        
    </script>
</html>