<html>
    <head>
    <script>
        
            alert("Your Business Account login is successfull")
        
    </script>
    </head>
</html>