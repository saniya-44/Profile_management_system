<html>
    <head>
    <script>
        
            alert("your institution account is successfully login")
        
    </script>
    </head>
</html>