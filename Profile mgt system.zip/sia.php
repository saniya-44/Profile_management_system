<?php
$uemail=$_POST['em'];
$upass=$_POST['pas'];
$con=new mysqli("localhost","root","","databse");
if(!$con)
{

    die("connection is failed".mysqli_error());
}
$sql="DELETE FROM tycoa2 WHERE uemail='$uemail' AND upass='$upass'";
$result=mysqli_query($con,$sql);
if(mysqli_affected_rows($con)>0)
{
    echo "<h1 align='center'>Your Institiution Account Logout successfully</h1>";
}
else{
    echo "<h1 align='center'>Your Institiution Account   unsuccessfully Plaese enter Correct Email-ID or Password</h1>";
}
?>
