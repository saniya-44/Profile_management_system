<?php
  $un=$_POST['in1'];
  $uemail=$_POST['in2'];
  $upass=$_POST['in3'];
  $mon=$_POST['in4'];
  $intn=$_POST['in5'];
  $intc=$_POST['in6'];
  $intl=$_POST['in7'];
  $gopr=$_POST['in8'];
  $intad=$_POST['in9'];
  $intst=$_POST['in10'];
  $intd=$_POST['in11'];
  $intp=$_POST['in12'];
  $id=$_POST['id6'];

  $host='localhost';
  $user='root';
  $pass='';
  $dbname='databse';

  $conn=mysqli_connect($host,$user,$pass,$dbname);
  $sql="UPDATE tycoa2 SET un='$un',uemail='$uemail',upass='$upass',mon='$mon',intn='$intn',intc='$intc',intl='$intl',gopr='$gopr',intad='$intad',
  intst='$intst',intd='$intd',intp='$intp',id='$id' WHERE id=$id";
  if($conn->query($sql)===TRUE)
  {
      echo "<h1 align='center'>your Institiution account is updated</h1>";
      }
      else
      {
          echo "<h1 align='center'>your Institiution account is not updated</h1>";
    }
  
?>