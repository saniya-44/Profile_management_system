<?php
if(isset($_POST['click']))
{
  $un=$_POST['in1'];
  $uemail=$_POST['in2'];
  $upass=$_POST['in3'];
  $mon=$_POST['in4'];
  $intn=$_POST['in5'];
  $intc=$_POST['in6'];
  $intl=$_POST['in7'];
  $gopr=$_POST['in8'];
  $intad=$_POST['in9'];
  $intst=$_POST['in10'];
  $intd=$_POST['in11'];
  $intp=$_POST['in12'];
  $id=$_POST['id7'];

  $host='localhost';
  $user='root';
  $pass='';
  $dbname='databse';

  $conn=mysqli_connect($host,$user,$pass,$dbname);
  $sql="INSERT INTO tycoa2(un,uemail,upass,mon,intn,intc,intl,gopr,intad,intst,intd,intp,id) values('$un','$uemail','$upass','$mon','$intn','$intc','$intl','$gopr','$intad','$intst','$intd','$intp','$id')";
  $query_run=mysqli_query($conn,$sql);
  if($query_run)
  {
    $query="SELECT * FROM tycoa2 where uemail='$uemail' and  upass='$upass'";
      if($result=mysqli_query($conn,$query))
      {
        if(mysqli_num_rows($result)>0)
        {
          
          echo "<table border=1 align='center' bordercolor='blue'>";
          echo "<tr>";
          echo "<th>username</th>";
          echo "<th>Email</th>";
          echo "<th>password</th>";
          echo "<th>Mobile Number</th>";
          echo "<th>Institiution Name</th>";
          echo "<th>Institiution Code</th>";
          echo "<th>Institiution Logo</th>";
          echo "<th>Institiution Government/Private</th>";
          echo "<th>Institiution address</th>";
          echo "<th>Institiution Staff name</th>";
          echo "<th>Institiution Designation</th>";
          echo "<th>Institiution Photo</th>";
          echo "<th>ID</th>";
          echo "</tr>";
      $query_run=mysqli_query($conn,$query);
      while($row=mysqli_fetch_array($query_run))
      {
        echo "<u><h1 align='center'>Your Institiution Account is successfuly created".$row['un']."</h1></u>";

        echo "<tr>";
        echo "<td>".$row['un']."</td>";
        echo "<td>".$row['uemail']."</td>";
        echo "<td>".$row['upass']."</td>";
        echo "<td>".$row['mon']."</td>";
        echo "<td>".$row['intn']."</td>";
        echo "<td>".$row['intc']."</td>";
        echo "<td>".$row['intl']."</td>";
        echo "<td>".$row['gopr']."</td>";
        echo "<td>".$row['intad']."</td>";
        echo "<td>".$row['intst']."</td>";
        echo "<td>".$row['intd']."</td>";
        echo "<td>".$row['intp']."</td>";
        echo "<td>".$row['id']."</td>";
        echo "</tr>";
    }
    echo "</table>";
    }
    echo "<p align='center'><a href='si.php'>logout your Institiution Account</a></p>";
    echo "<p align='center'><a href='updateinst.php'>Update your Institiution Account</a></p>";
  }
    }
  
  else{
    header("Location:iaa1.php");
  }
}
?>