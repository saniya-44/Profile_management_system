<?php
$host='localhost';
  $user='root';
  $pass='';
  $dbname='mydatabse';

  $conn=mysqli_connect($host,$users,$pass,$dbname);
  if($conn->connect_error)
  {
    die("connection faliled:".$conn->connect_error);
  }
  else
  {
    echo"connection successfull";
  }
?>