<?php
$uemail=$_POST['email'];
$upass=$_POST['pass'];
$con=new mysqli("localhost","root","","databse");
if($con->connect_error){
  die("failed to connect:".$con->conect_error);
}
else{
  $stmt=$con->prepare("select *from tycoa where uemail=?");
  $stmt->bind_param("s",$uemail);
  $stmt->execute();
  $stmt_result=$stmt->get_result();
  if($stmt_result->num_rows>0){
    $data=$stmt_result->fetch_assoc();
    if($data['upass']==$upass){
      $query="SELECT * FROM tycoa where uemail='$uemail' and  upass='$upass'";
      if($result=mysqli_query($con,$query))
      {
        if(mysqli_num_rows($result)>0)
        {
          
          echo "<table border=1 align='center' bordercolor='blue'>";
          echo "<tr>";
          echo "<th>username</th>";
          echo "<th>Business Name</th>";
          echo "<th>Business Description</th>";
          echo "<th>Business Address</th>";
          echo "<th>mobile number</th>";
          echo "<th>Email</th>";
          echo "<th>password</th>";
          echo "<th>ID</th>";
          echo "</tr>";
      $query_run=mysqli_query($con,$query);
      while($row=mysqli_fetch_array($query_run))
      {
        echo "<u><h1 align='center'>welcome ".$row['uname']."</h1></u>";

        echo "<tr>";
        echo "<td>".$row['uname']."</td>";
        echo "<td>".$row['bname']."</td>";
        echo "<td>".$row['bdes']."</td>";
        echo "<td>".$row['badd']."</td>";
        echo "<td>".$row['contact']."</td>";
        echo "<td>".$row['uemail']."</td>";
        echo "<td>".$row['upass']."</td>";
        echo "<td>".$row['id']."</td>";
        echo "</tr>";
    }
    echo "</table>";
    }
    echo "<p align='center'><a href='sb.php'>logout your Business Account</a></p>";
    echo "<p align='center'><a href='updatebusines.php'>Update your Business Account</a></p>";
    echo "<p align='center'><a href='#'><select id='theme-selector' onchange='color()'>
    <option value='1'>Select Theme</option>
    <option value='lightblue'>Light Blue</option>
    <option value='blue'>Blue</option>
    <option value='lightgreen'>Light Green</option>
    <option value='green'>Green</option>
    <option value='lightgray'>Light Gray</option>
    <option value='gray'>Gray</option>
    <option value='lightyellow'>Light Yellow</option>
    <option value='yellow'>Yellow</option>
    <option value='lightpink'>Light Pink</option>
    <option value='pink'>Pink</option>
    <option value='red'>Red</option>
    <option value='orange'>Orange</option>
    <option value='brown'>Brown</option>
  </select></a></p>";
  
  echo "<script>";
  echo "function color(){
    var x=document.getElementById('theme-selector').value;
    document.body.style.backgroundColor=x;
}";
echo "</script>";
  }
    }
    else{
      header("Location:blogin2.php");
    }
  }
  else{
    header("Location:blogin2.php");
  }
}
?>